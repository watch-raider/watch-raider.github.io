/***************************
This is JavaScript (JS), the programming language that powers the web (and this is a comment, which you can delete).

To use this file, link it to your markup by placing a <script> in the <body> of your HTML file:

  <body>
    <script src="script.js"></script>

replacing "script.js" with the name of this JS file.

Learn more about JavaScript at

https://developer.mozilla.org/en-US/Learn/JavaScript
***************************/

function greetMe(name) {
  var today = new Date();
  alert("Hello " + name + ", today is " + today.toDateString());
}

//2014-15

$('.choice').hide();

$('.seek').on('click', function() {
   $('.choice').toggle();
});

//2013-14

$('.choice1').hide();

$('.seek1').on('click', function() {
  $('.choice1').toggle();
});

//2012-13

$('.choice2').hide();

$('.seek2').on('click', function() {
  $('.choice2').toggle();
});

//2011-12

$('.choice3').hide();

$('.seek3').on('click', function() {
  $('.choice3').toggle();
});

//2010-11

$('.choice4').hide();

$('.seek4').on('click', function() {
  $('.choice4').toggle();
});

